package vde

var sectionsDataSQL = `
INSERT INTO "%[1]d_sections" ("id","title","urlname","page","roles_access", "delete") VALUES
('1', 'Home', 'home', 'default_page', '', 0);`
